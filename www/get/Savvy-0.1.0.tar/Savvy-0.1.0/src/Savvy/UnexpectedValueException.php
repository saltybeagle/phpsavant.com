<?php
class Savvy_UnexpecteValueException implements Savvy_Exception extends \UnexpectedValueException
{

}
