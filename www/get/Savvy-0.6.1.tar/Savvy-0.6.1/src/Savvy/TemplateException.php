<?php
class Savvy_TemplateException extends Exception implements Savvy_Exception {}
?>