<?php

interface Savvy_FastCompilerInterface extends Savvy_CompilerInterface
{
}