<?php

interface Savvy_MapperInterface
{
    function map($name);
}