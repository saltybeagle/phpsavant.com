<?php

interface Savvy_CompilerInterface
{
    function compile($savvy, $name);
}