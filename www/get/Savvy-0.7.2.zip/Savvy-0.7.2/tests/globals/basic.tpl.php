<?php
    if (isset($foo)
        && true === $foo) {
        echo '===DONE===';
    }
?>