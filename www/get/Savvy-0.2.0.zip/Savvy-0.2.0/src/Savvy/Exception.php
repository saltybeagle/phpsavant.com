<?php
interface Savvy_Exception
{

}
?>