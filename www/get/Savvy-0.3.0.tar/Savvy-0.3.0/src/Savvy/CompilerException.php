<?php
class Savvy_CompilerException extends Exception implements Savvy_Exception {}
?>