<?php
class Savvy_UnexpectedValueException extends UnexpectedValueException implements Savvy_Exception
{

}
