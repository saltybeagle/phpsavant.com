<p>This is a paragraph with a date of <?php echo $this->date($this->date) ?></p>
