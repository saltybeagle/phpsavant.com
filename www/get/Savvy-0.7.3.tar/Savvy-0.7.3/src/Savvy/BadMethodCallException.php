<?php
class Savvy_BadMethodCallException extends BadMethodCallException implements Savvy_Exception {}